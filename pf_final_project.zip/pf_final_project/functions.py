from math import sin,cos,tan
from math import pi, log , log10
ERROR_MSG = 'ERROR'


def factorial(n):                      
    n = n[:-1]                           
    n =int(n)                            
    fact = 1
    for i in range(1,n+1):
        fact *= i
    return str(fact)

def get_sin(a):
    start = a.index('s')
    if a[0] != 's':
        part1 = a[:start]
    else:
        part1 =''

    a = a[start+4:-1]
    a = eval(a)             #solving brackets inside sin
    part2 = sin(a)          #solving sin
    expr = str(part1) + str(part2)
    result = eval(expr)
    return str(result)

get_sin('2*sin((1/2)*pi)')

def get_cos(a):
    start = a.index('c')
    if a[0] != 'c':
        part1 = a[:start]
    else:
        part1 =''

    a = a[start+4:-1]
    a = eval(a)             
    part2 = cos(a)       
    expr = str(part1) + str(part2)
    result = eval(expr)
    return str(result)

# print(get_cos('cos((2/3)*pi)'))

def get_tan(a):
    start = a.index('t')
    if a[0] != 't':
        part1 = a[:start]
    else:
        part1 =''

    a = a[start+4:-1]
    a = eval(a)             
    part2 = tan(a)        
    expr = str(part1) + str(part2)
    result = eval(expr)
    return str(result)


def solvePi(a):
    start = a.index('p')
    pi_ = a[start:]
    a = a[:start]
    num =''
    operator = ''
    for i in a:
        if i.isdigit():
            num += i
        else:
            operator += i
    
    expr = str(num) + str(operator) + str(pi_)
    try:
        result = eval(expr)
    except Exception:
        result = ERROR_MSG
    finally:
        return str(result)
    
def get_log(a):
    start = a.index('l')
    if a[0] != 'l':
        part1 = a[:start] 
    else:
        part1 =''

    a = a[start+4:-1]      
    a = eval(a)             
    part2 = log(a)          
    expr = str(part1) + str(part2)
    result = eval(expr)
    return str(result)

def get_log10(a):
    start = a.index('l')
    if a[0] != 'l':
        part1 = a[:start] 
    else:
        part1 =''

    a = a[start+6:-1]      
    a = eval(a)             
    part2 = log10(a)          
    expr = str(part1) + str(part2)
    result = eval(expr)
    return str(result)

def get_trunc(a):
    start = a.index('t')
    if a[0] != 't':
        part1 = a[:start]
    else:
        part1 =''

    a = a[start+6:-1] 
    decimal = float(a) - int(float(a))    
    part2 = round(float(a) - decimal)   
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)

def round_float(a):
    start = a.index('f')
    if a[0] != 'f':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+6:-1]  
    decimal = float(a) - int(float(a))
    if decimal >= 0.5:
        part2 = int(float(a)) + 1
    else:
        part2 = int(float(a))  
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)


def get_floor(a):
    start = a.index('f')
    if a[0] != 'f':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+6:-1]  
    part2 = int(float(a))  
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)

def get_ceil(a):
    start = a.index('c')
    if a[0] != 'c':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+5:-1]  
    part2 = int(float(a)) + 1  
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)

def get_sqrt(a):
    start = a.index('s')
    if a[0] != 's':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+5:-1]  
    part2 = float(a)**(1/2) 
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)


def get_cbrt(a):
    start = a.index('c')
    if a[0] != 'c':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+5:-1]  
    part2 = float(a)**(1/3) 
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)


def get_gcd(a):
    start = a.index('g')
    if a[0] != 'g':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+4:-1]  
    num1, num2 = a.split('-')
    num1, num2 = int(num1),int(num2)
    div = 1
    while (div <= num1) and (div <= num2):
        if (num1 % div == 0) and (num2 % div== 0):
            gcd = div
        div += 1
    part2 = gcd
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)

def get_lcm(a):
    start = a.index('l')
    if a[0] != 'l':
        part1 = a[:start]  
    else:
        part1 =''

    a = a[start+4:-1]  
    num1, num2 = a.split('-')
    num1, num2 = int(num1),int(num2)
    if num1>num2:
        maxNum, minNum = num1,num2
    else:
        maxNum, minNum = num2,num1
    if maxNum % minNum ==0:
        lcm = maxNum
    else:
        while True:
            if maxNum % num1 == 0 and maxNum % num2 ==0:
                lcm = maxNum
                break
            else:
                maxNum += 1
    part2 = lcm
    expr = str(part1) + str(part2)
    result = eval(expr)

    return str(result)


def decimal2binary(a):
    start = a.index('d')
    if a[0] != 'd':
        result = ERROR_MSG

    new_number =[]
    d = int(a[start+4:-1])
    n = 2
    while d > 0:
        a = d // n 
        b = d % n 
        d = a
        new_number.append(b)
    new_number.reverse()
    
    result =''
    for n in new_number:
        result += str(n)

    return str(result)

def binary2decimal(a):
    start = a.index('b')
    if a[0] != 'b':
        result = ERROR_MSG
    binarynum = a[start+4:-1]

    conversion_chamber = []
    decimal_number= []

    for i in binarynum:
        conversion_chamber.append(int(i))
    
    for i in range(1,(len(conversion_chamber)+1)):
        value = conversion_chamber[-i] * (2**(i-1))
        decimal_number.append(value) 

    count = 0
    for d in decimal_number:
        count += d
    result = count

    return str(result)