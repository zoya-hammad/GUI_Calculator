import sys     #provides exit function, which is used to terminate the app
from PyQt5.QtWidgets import QApplication,QMainWindow,QWidget, QGridLayout,QLineEdit,QPushButton,QVBoxLayout
from functools import partial 
from PyQt5.QtGui import QFont
from tabulate import tabulate
from functions import *
import time  
from datetime import datetime

WINDOW_WIDTH = 640   
WINDOW_HEIGHT = 340
DISPLAY_HEIGHT = 60
BUTTON_SIZE = 60
ERROR_MSG = 'ERROR'

class PyCalcWindow(QMainWindow):  
    def __init__(self):
        super().__init__()   

        self.setWindowTitle('Calculator')
        self.setFixedSize(WINDOW_WIDTH,WINDOW_HEIGHT)  
        self.generalLayout = QVBoxLayout()
        centralWidget = QWidget()   
        centralWidget.setLayout(self.generalLayout)
        self.setCentralWidget(centralWidget) 
        self._createDisplay()
        self._createButtons()
        global results 
        results = []

    def _createDisplay(self):
        self.display = QLineEdit()
        self.display.setStyleSheet("background-color:white;border-radius:10px;border:2px solid black;")
        self.display.setFixedHeight(DISPLAY_HEIGHT)
        self.display.setReadOnly(True) 
        self.generalLayout.addWidget(self.display)

    def _createButtons(self):
        self.buttonMap = {}  
        buttonLayout = QGridLayout()
        keyBoard = [                   
            ["7", "8", "9", "/", "%","sin" ,"round","sqrt","d2b","CLR"],
            ["4", "5", "6", "*","**" ,"cos","trunc","cbrt","b2d","("],
            ["1", "2", "3", "-","abs", "tan","floor","gcd","log",")"],
            ["0", "00", ".", "+","!","pi", "ceil","lcm","log10","="],
        ]

        for row,keys in enumerate(keyBoard):
            for col,key in enumerate(keys):
                self.buttonMap[key] = QPushButton(key)
                self.buttonMap[key].setFixedSize(BUTTON_SIZE,BUTTON_SIZE)
                buttonLayout.addWidget(self.buttonMap[key],row,col)
        self.generalLayout.addLayout(buttonLayout)

    def setDisplayText(self,text):
        self.display.setText(text)          
        self.display.setFont(QFont("arial",15))

    def displayText(self):
        return self.display.text()      
                                        
    def clearDisplay(self):
        self.setDisplayText("")          

def evaluateExpression(expression):
    try:
        result = str(eval(expression))
    except Exception:
        result = ERROR_MSG
    return result


class pyCalc:
    def __init__(self,model,view):
        self._evaluate = model
        self._view = view
        self._view.setFont(QFont("arial",10))
        self._view.setStyleSheet('''QPushButton{background-color:#fddfdf;border-radius:10px;border:2px solid black;}
        QPushButton:hover{background-color:white;}
        QPushButton:pressed{background-color: transparent;}''')

        self._connectSignalsAndSlots()

    def _calculateResult(self):
        exp = self._view.displayText()
        if '!' in exp[-1] and exp.count('!') == 1:
            result = factorial(exp)
        elif 'sin' in exp:
            result = get_sin(exp)
        elif 'cos' in exp:
            result = get_cos(exp)
        elif 'tan' in exp:
            result = get_tan(exp)
        elif 'pi' in exp:
            result = solvePi(exp)
        elif 'log' in exp:
            result = get_log(exp)
        elif 'round' in exp:
            result = round_float(exp)
        elif 'trunc' in exp:
            result = get_trunc(exp)
        elif 'floor' in exp:
            result = get_floor(exp)
        elif 'ceil' in exp:
            result = get_ceil(exp)
        elif 'sqrt' in exp:
            result = get_sqrt(exp)
        elif 'cbrt' in exp:
            result = get_cbrt(exp)
        elif 'gcd' in exp:
            result = get_gcd(exp)
        elif 'lcm' in exp:
            result = get_lcm(exp)
        elif 'd2b' in exp:
            result = decimal2binary(exp)
        elif 'b2d' in exp:
            result = binary2decimal(exp)
        elif 'log' in exp:
            result = get_log(exp)
        elif 'log10' in exp:
            result = get_log10(exp)
        else:
            result = evaluateExpression(exp) 
        self._view.setDisplayText(result)
        results.append((exp,result))

        time_stamp = time.time()
        date_time = datetime.fromtimestamp(time_stamp)

        headers = ["Expression Entered", "Result", "Date and Time"]
        table = tabulate([ (results[i][0] , results[i][1] , date_time)for i in range(len(results))], headers=headers)
        print(table)

        with open("C:\\Users\\92310\\Desktop\\pf_final_project\\calcdata.txt", "w") as f:
            f.write(table)
            f.close()

    def _buildExpression(self, subExpression):    
        screen = self._view.displayText()
        if screen == ERROR_MSG:
            self._view.clearDisplay()
        expression = screen + subExpression
        self._view.setDisplayText(expression)

    def _connectSignalsAndSlots(self):
        for keySymbol, button in self._view.buttonMap.items():
            if keySymbol not in ["=", "CLR"]:
                button.clicked.connect(
                    partial(self._buildExpression, keySymbol)
                )
        self._view.buttonMap["="].clicked.connect(self._calculateResult)
        self._view.buttonMap["CLR"].clicked.connect(self._view.clearDisplay)

def main():
    pycalcApp = QApplication([])   #creates a QApplication object named pycalcApp.
    pycalcWindow = PyCalcWindow()  #creates an instance of the app’s window, pycalcWindow.
    pycalcWindow.show()           #shows the GUI by calling .show() on the window object.
    pyCalc(model=evaluateExpression, view=pycalcWindow)
    sys.exit(pycalcApp.exec())     #runs the application’s event loop with .exec().

if __name__ == '__main__':
    main()





